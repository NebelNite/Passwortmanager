package com.example.Passwortmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasswortmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
