import CryptoJS = require("./index");

export = CryptoJS.pad.Iso10126;
