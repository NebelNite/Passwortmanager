import CryptoJS = require("./index");

export = CryptoJS.MD5;
