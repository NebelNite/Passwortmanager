import CryptoJS = require("./index");

export = CryptoJS.PBKDF2;
