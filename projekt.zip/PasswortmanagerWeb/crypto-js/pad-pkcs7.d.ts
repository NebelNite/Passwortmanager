import CryptoJS = require("./index");

export = CryptoJS.pad.Pkcs7;
