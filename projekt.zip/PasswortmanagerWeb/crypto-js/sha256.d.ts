import CryptoJS = require("./index");

export = CryptoJS.SHA256;
