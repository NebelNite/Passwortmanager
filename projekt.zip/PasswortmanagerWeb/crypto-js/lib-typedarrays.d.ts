import CryptoJS = require("./index");

export = CryptoJS.lib.WordArray;
