import CryptoJS = require("./index");

export = CryptoJS.pad.AnsiX923;
