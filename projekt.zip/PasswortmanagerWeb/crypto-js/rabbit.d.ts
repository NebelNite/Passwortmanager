import CryptoJS = require("./index");

export = CryptoJS.Rabbit;
