import CryptoJS = require("./index");

export = CryptoJS.HmacSHA384;
