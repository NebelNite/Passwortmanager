import CryptoJS = require("./index");

export = CryptoJS.pad.NoPadding;
