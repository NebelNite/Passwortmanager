import CryptoJS = require("./index");

export = CryptoJS.enc.Utf8;
