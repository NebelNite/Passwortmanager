import CryptoJS = require("./index");

export = CryptoJS.enc.Latin1;
