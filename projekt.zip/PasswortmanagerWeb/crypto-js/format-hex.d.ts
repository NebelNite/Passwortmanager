import CryptoJS = require("./index");

export = CryptoJS.format.Hex;
