import CryptoJS = require("./index");

export = CryptoJS.RabbitLegacy;
