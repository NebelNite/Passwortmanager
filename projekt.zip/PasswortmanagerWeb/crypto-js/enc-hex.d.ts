import CryptoJS = require("./index");

export = CryptoJS.enc.Hex;
