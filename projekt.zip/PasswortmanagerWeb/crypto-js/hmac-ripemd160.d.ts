import CryptoJS = require("./index");

export = CryptoJS.HmacRIPEMD160;
