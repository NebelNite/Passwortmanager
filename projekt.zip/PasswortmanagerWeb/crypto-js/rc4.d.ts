import CryptoJS = require("./index");

export = CryptoJS.RC4;
