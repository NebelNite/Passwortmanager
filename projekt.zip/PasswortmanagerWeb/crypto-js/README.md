# Installation
> `npm install --save @types/crypto-js`

# Summary
This package contains type definitions for crypto-js (https://github.com/brix/crypto-js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/crypto-js.

### Additional Details
 * Last updated: Mon, 22 Jan 2024 06:37:11 GMT
 * Dependencies: none

# Credits
These definitions were written by [Michael Zabka](https://github.com/misak113), [Max Lysenko](https://github.com/maximlysenko), [Brendan Early](https://github.com/mymindstorm), and [Doma](https://github.com/SevenOutman).
