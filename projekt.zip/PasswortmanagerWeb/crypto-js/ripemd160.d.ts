import CryptoJS = require("./index");

export = CryptoJS.RIPEMD160;
