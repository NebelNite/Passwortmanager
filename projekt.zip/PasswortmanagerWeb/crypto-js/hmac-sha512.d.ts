import CryptoJS = require("./index");

export = CryptoJS.HmacSHA512;
