
export class UserDTO {
  
  constructor() {
    this.id = '';
    this.username = '';
    this.entries = [];
    this.masterKey = '';
  }
  
}
