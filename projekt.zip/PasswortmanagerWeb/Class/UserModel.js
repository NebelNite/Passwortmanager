
import { EntryModel } from "../Class/EntryModel.js";
import { UserDTO } from "../Class/UserDTO.js";




export class UserModel {
  constructor() {
    this.id = '';
    this.username = '';
    this.entries = [];
    this.masterKey = '';
  }



}