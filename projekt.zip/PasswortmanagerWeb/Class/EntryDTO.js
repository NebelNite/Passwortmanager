
export class EntryDTO {
    constructor() {
      this.id = '';
      this.title = '';
      this.username = '';
      this.password = '';
      this.url = '';
      this.notes = '';
    }
  }
  